package es.codeurjc.web.nitflex.dto.review;

public record CreateReviewRequest(String text, int score) {}