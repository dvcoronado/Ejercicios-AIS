package es.codeurjc.web.nitflex.dto.user;

public record UserSimpleDTO(Long id, String name, String email) {}