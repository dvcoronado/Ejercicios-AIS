package es.codeurjc.web.nitflex.dto.film;

public record FilmSimpleDTO(Long id, String title, String synopsis, int releaseYear, String ageRating) {}

